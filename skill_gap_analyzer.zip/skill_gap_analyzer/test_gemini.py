import google.genai as genai
from flask import Flask, render_template, request, flash, redirect, url_for, session
from dotenv import load_dotenv
import os
import json
import re

load_dotenv()
app = Flask(__name__)
app.secret_key = 'skillgap_secret'

# Initialize the Gemini client only if an API key is provided. Keep it None otherwise
# so the app can still run in demo/offline mode.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

# Predefined role skills (expandable; based on common IT roles) [web:8][web:13]
ROLE_SKILLS = {
    'Software Developer': ['Python', 'JavaScript', 'Git', 'SQL', 'Docker', 'System Design', 'Problem Solving', 'Teamwork'],
    'Data Analyst': ['Python', 'SQL', 'Excel', 'Pandas', 'Tableau', 'Statistics', 'Data Viz', 'Communication']
}

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/student', methods=['GET', 'POST'])
def student_details():
    if request.method == 'POST':
        branch = request.form['branch']
        year = request.form['year']
        role = request.form['role']
        current_skills = [s.strip() for s in request.form['current_skills'].split(',') if s.strip()]
        
        session_data = {
            'branch': branch, 'year': year, 'role': role,
            'current_skills': current_skills,
            'required_skills': ROLE_SKILLS.get(role, [])
        }
        session.clear()
        session.update(session_data)  # Flask session for simplicity
        return redirect(url_for('analysis'))
    
    return render_template('student.html')

@app.route('/analysis')
def analysis():
    if 'role' not in session:
        flash('Please submit student details first.')
        return redirect(url_for('student_details'))
    
    data = session
    prompt = f""" Present the following as different apragraphs and points to give a summarised ai insight. Only display the result
    Analyze skill gap for {data['branch']} {data['year']} student targeting {data['role']} role.
    Required skills: {', '.join(data['required_skills'])}
    Current skills: {', '.join(data['current_skills'])}
    Provide: readiness score (0-100), gap list with priority (High/Med/Low), 3-5 roadmap steps with timelines.
    Format as JSON: {{"score": 85, "gaps": [{{"skill": "Docker", "priority": "High"}}], "roadmap": ["Learn Docker (1 week)", ...]}}
    """

    # Default demo analysis values (used if the API call fails or the key is missing)
    analysis = None
    demo_score = 0

    # Compute a simple demo score based on skill overlap
    try:
        overlap = len(set(data['current_skills']) & set(data['required_skills']))
        demo_score = min(100, int((overlap / len(data['required_skills'])) * 100)) if data['required_skills'] else 0
    except Exception:
        demo_score = 0

    # If we have a configured client, try a request to Gemini; otherwise fall back to demo text
    if client:
        try:
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )

            # response object shapes vary; prefer .text then .content then str()
            if isinstance(response, dict):
                analysis_text = response.get('text') or json.dumps(response)
            else:
                analysis_text = getattr(response, 'text', None) or getattr(response, 'content', None) or str(response)

            # Try to pretty-print JSON if the model returned JSON
            try:
                parsed = json.loads(analysis_text)
                analysis = json.dumps(parsed, indent=2)
            except Exception:
                analysis = analysis_text
        except Exception as e:
            analysis = f"Error calling Gemini API: {e}. Using demo analysis."
    else:
        analysis = "No GEMINI_API_KEY provided — showing demo analysis."
    
    return render_template('analysis.html', data=data, score=demo_score, analysis=analysis)

if __name__ == '__main__':
    app.run(debug=True)